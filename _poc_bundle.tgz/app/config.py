"""Settings loaded from environment / .env."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


@dataclass(frozen=True)
class Settings:
    openai_base_url: str = _env("OPENAI_BASE_URL")
    openai_api_key: str = _env("OPENAI_API_KEY")
    llm_model: str = _env("LLM_MODEL", "gpt-5.2")

    embedding_provider: str = _env("EMBEDDING_PROVIDER", "openai").lower()
    embedding_model: str = _env("EMBEDDING_MODEL", "text-embedding-3-small")

    milvus_uri: str = _env("MILVUS_URI", "./data/milvus_memory.db")
    milvus_token: str = _env("MILVUS_TOKEN")
    milvus_collection: str = _env("MILVUS_COLLECTION", "agent_memories")

    agent_namespace: str = _env("AGENT_NAMESPACE", "poc-agent")
    default_user_id: str = _env("DEFAULT_USER_ID", "earth")

    tavily_api_key: str = _env("TAVILY_API_KEY")

    @property
    def resolved_milvus_uri(self) -> str:
        """Relative Milvus Lite paths are resolved against the project root."""
        uri = self.milvus_uri
        if uri.startswith(("http://", "https://", "tcp://", "unix:")):
            return uri
        path = Path(uri)
        if not path.is_absolute():
            path = ROOT / path
        path.parent.mkdir(parents=True, exist_ok=True)
        return str(path)


settings = Settings()
